/*document.getElementById("btnEntrar").addEventListener("click", function() {
    // Pegando os valores digitados
    let email = document.getElementById("email").value;
    let senha = document.getElementById("senha").value;

    // Definindo um usuário fixo para simular um login correto
    let emailCorreto = "teste@email.com";
    let senhaCorreta = "123456";

    if (email === emailCorreto && senha === senhaCorreta) {
        // Se o login estiver correto, redireciona para outra página
        window.location.href = "home.html"; // Substitui "home.html" pela sua página
    } else {
        // Se o login estiver errado, mostra o erro
        document.getElementById("modalErro").style.display = "flex";
    }
});

// Fecha o modal ao clicar no botão "ok"
document.getElementById("btnFecharErro").addEventListener("click", function() {
    document.getElementById("modalErro").style.display = "none";
});
*/
