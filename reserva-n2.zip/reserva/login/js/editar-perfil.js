document.addEventListener("DOMContentLoaded", function() {
    const formEditar = document.getElementById("editar-perfil-form");

    if (formEditar){
        formEditar.addEventListener("submit", function(e){

            e.preventDefault();

            const nome = document.getElementById("nome").value.trim();
            const cpf = document.getElementById("cpf").value.trim();
            const telefone = document.getElementById("telefone").value.trim();
            const email = document.getElementById("email").value.trim();
            const senha = document.getElementById("senha").value.trim();
            const confirmarSenha = document.getElementById("confirmar-senha").value.trim();

            if (!nome || !cpf || !telefone || !email) {
                const modalErroCampos = document.getElementById("modalErroCampos");

                if (modalErroCampos) {
                    modalErroCampos.style.display = "flex";
                }

                return;
            }

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                const modalErroEmail = document.getElementById("modalErroEmail");
                if (modalErroEmail) {
                    modalErroEmail.style.display = "flex";
                }
                return;
            }

            const cpfRegex = /^\d{3}\.\d{3}\.\d{3}-\d{2}$/;
            if (!cpfRegex.test(cpf)) {
                const modalErroCampos = document.getElementById("modalErroCampos");
                if (modalErroCampos) {
                    modalErroCampos.style.display = "flex";
                }
                return;
            }

            const telefoneRegex = /^\(\d{2}\) \d{5}-\d{4}$/;
            if (!telefoneRegex.test(telefone)) {
                const modalErroCampos = document.getElementById("modalErroCampos");
                if (modalErroCampos) {
                    modalErroCampos.style.display = "flex";
                }
                return;
            }

            if (senha || confirmarSenha) {
                if (senha !== confirmarSenha) {
                    const modalErroSenhas = document.getElementById("modalErroSenhas");
                    if (modalErroSenhas) {
                        modalErroSenhas.style.display = "flex"; 
                    }
                    return; 
                }
            }

            // se passar por tudo
            window.location.href = "perfil.html";
        });
        

        // mascara de cpf
        const inputCPF = document.getElementById("cpf");
        if (inputCPF) {
            inputCPF.addEventListener("input", function (e){
                let value = e.target.value.replace(/\D/g, '');
                value = value.slice(0,11);

                if(value.length > 9) {
                    value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{1,2})/, "$1.$2.$3-$4");
                }else if (value.length > 6){
                    value = value.replace(/(\d{3})(\d{3})(\d{1,3})/, "$1.$2.$3");
                } else if (value.length > 3) {
                    value = value.replace(/(\d{3})(\d{1,3})/, "$1.$2");
                }

                e.target.value = value;
            });
        }

        // mascara de telefone
        const inputTelefone = document.getElementById("telefone");
        if (inputTelefone) {
            inputTelefone.addEventListener("input", function(e){
                let value = e.target.value.replace(/\D/g, '');
                value = value.slice(0,11);

                if (value.length > 6) {
                    value = value.replace(/(\d{2})(\d{5})(\d{0,4})/, "($1) $2-$3");
                } else if (value.length > 2) {
                    value = value.replace(/(\d{2})(\d{0,5})/, "($1) $2");
                } else {
                    value = value.replace(/(\d{0,2})/, "($1");
                }

                e.target.value = value;
            });
        }

        // fechar modais
        document.getElementById("btnFecharErroSenhas").addEventListener("click", () => {
            document.getElementById("modalErroSenhas").style.display = "none";
        });

        document.getElementById("btnFecharErroCampos").addEventListener("click", () => {
            document.getElementById("modalErroCampos").style.display = "none";
        });

        document.getElementById("btnFecharErroEmail").addEventListener("click", () => {
            document.getElementById("modalErroEmail").style.display = "none";
        });

        // botao cancelar edição
        document.getElementById("cancelar-editar-perfil").addEventListener("click", () => {
            window.location.href = "perfil.html";
        });
        
    }


    // Botão do menu: Painel
    document.getElementById("link-editar-perfil-painel").addEventListener("click", (e) => {
        e.preventDefault();
        window.location.href = "painel.html";
    });

    // Botão do menu: Clientes
    document.getElementById("link-editar-perfil-clientes").addEventListener("click", (e) => {
        e.preventDefault();
        window.location.href = "clientes.html";
    });

    // Botão do menu: Meu Perfil (quando estiver na tela de edição, volta pra visualização)
    document.querySelector(".nav-editar-perfil-links .active").addEventListener("click", (e) => {
        e.preventDefault();
        window.location.href = "perfil.html";
    });

    // Botão do menu: Sair
    document.getElementById("link-editar-perfil-sair").addEventListener("click", (e) => {
        e.preventDefault();
        window.location.href = "index.html";
    });

    // Botão inferior: Cancelar edição
    document.getElementById("cancelar-editar-perfil").addEventListener("click", () => {
        window.location.href = "perfil.html";
    });
    

    /* Dropdown Reservas */
    const botaoReservas = document.getElementById("btn-editar-perfil-reservas");
    const menuReservas = document.getElementById("menu-reservas-editar-perfil");
    
    botaoReservas.addEventListener("click", function (e){
        e.preventDefault();
        menuReservas.style.display = menuReservas.style.display === "block" ? "none" : "block";
    });
    
    //fechar dropdown se clicar fora
    document.addEventListener("click", function (e){
        const isClickInside = botaoReservas.contains(e.target) || menuReservas.contains(e.target);
        if (!isClickInside){
            menuReservas.style.display = "none";
        }
    });

}); 