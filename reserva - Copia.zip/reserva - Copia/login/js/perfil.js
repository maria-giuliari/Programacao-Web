document.getElementById('editar-perfil').addEventListener('click', () => {
    window.location.href = 'editar-perfil.html';
});


  
document.getElementById('remover-perfil').addEventListener('click', () => {
  document.getElementById('modal-remover').style.display = 'flex';
});

document.getElementById('cancelar-modal').addEventListener('click', () => {
  document.getElementById('modal-remover').style.display = 'none';
});

document.getElementById('confirmar-remover').addEventListener('click', () => {
  // chamar back para excluir o perfil
  
  // fechar o modal
  document.getElementById('modal-remover').style.display = 'none';

  // redireciona pra tela de login
  window.location.href = 'index.html';
});

  

document.getElementById("link-perfil-painel").addEventListener("click", (e) => {
    e.preventDefault();
    window.location.href = "painel.html";
}); 
  
document.getElementById("link-perfil-sair").addEventListener("click", (e) => {
    e.preventDefault();
    window.location.href = "index.html";
}); 