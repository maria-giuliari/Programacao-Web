
document.addEventListener("DOMContentLoaded", function () {
    const reservasHoje = [
        { nome: 'João Silva', data: '07/04/2025', hora: '12:00', pessoas: 3 },
        { nome: 'Maria Costa', data: '07/04/2025', hora: '13:00', pessoas: 2 },
        { nome: 'Carlos Souza', data: '07/04/2025', hora: '14:00', pessoas: 4 },
    ];

    const reservasFuturas = [
        { nome: 'Ana Paula', data: '08/04/2025', hora: '12:00', pessoas: 2 },
        { nome: 'Roberto Lima', data: '09/04/2025', hora: '15:00', pessoas: 6 },
    ];

    const hojeTbody = document.getElementById('painel-hoje');
    const futurasTbody = document.getElementById('painel-futuras');
    const contadorHoje = document.getElementById("contador-hoje");

    reservasHoje.forEach(reserva => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${reserva.nome}</td>
            <td>${reserva.data}</td>
            <td>${reserva.hora}</td>
            <td>${reserva.pessoas}</td>
            <td
                class="painel-status-confirmada">Confirmada
            </td>
            <td>
                <button class="painel-btn-cancelar">Cancelar</button>
            </td>
        `;
        hojeTbody?.appendChild(tr);
    });

    reservasFuturas.forEach(reserva => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${reserva.nome}</td>
            <td>${reserva.data}</td>
            <td>${reserva.hora}</td>
            <td>${reserva.pessoas}</td>
            <td>
                <button class="painel-btn-confirmar">Confirmar</button>
                <button class="painel-btn-cancelar">Cancelar</button>
            </td>
        `;
        futurasTbody?.appendChild(tr);
    });

    contadorHoje.textContent = reservasHoje.length;

    /*
    document.addEventListener("click", (e) => {
        const botao = e.target; 
        if(!botao.matches("button")) return;

        const linha = botao.closest("tr");
        const tabela = linha.closest("tbody");
        
        // cancelar 
       if (botao.classList.contains("painel-btn-cancelar")){
        const celulaStatus = linha.children[5];
        const celulaAcoes = linha.children[5];

        celulaStatus.textContent = "Cancelada";
        celulaStatus.className = "painel-status-cancelada";
        celulaAcoes.innerHTML = ""; //remove botoes
       }

       // confirmar (só existe nas reservas futuras)
       if(botao.classList.contains("painel-btn-confirmar")){
        const celulaStatus = linha.children[5];
        const celulaAcoes = linha.children[5];

        celulaStatus.textContent = "Confirmada";
        celulaStatus.className = "painel-status-confirmada";
        celulaAcoes.innerHTML = ""; // remove botoes
       }
    });
    */

    document.addEventListener("click", (e) => {
      const botao = e.target; 
      if (!botao.matches("button")) return; 

      const linha = botao.closest("tr"); 

      // Cancelar 
      if (botao.classList.contains("painel-btn-cancelar")){
        if (linha.parentElement.id === "painel-hoje") {
          // para tabela do dia
          const celulaStatus = linha.children[4]; 
          const celulaAcoes = linha.children[5]; 
          celulaStatus.textContent = "Cancelada"; 
          celulaStatus.className = "painel-status-cancelada"; 
          celulaAcoes.innerHTML = ""; 
        } else {
          // para próximos dias (futura)
          const celulaAcoes = linha.children[4];
          celulaAcoes.textContent = "Cancelada"; 
          celulaAcoes.className = "painel-status-cancelada";
        }
      }

      // Confirmar (apenas nos proximos dias)
      if(botao.classList.contains("painel-btn-confirmar")) {
        const celulaAcoes = linha.children[4]; 
        celulaAcoes.textContent = "Confirmada"; 
        celulaAcoes.className = "painel-status-confirmada"; 
      }
    });



       /* if(botao.classList.contains("painel-btn-cancelar")){
            linha.children[4].textContent = "Cancelada";
            linha.children[4].className = "painel-status-cancelada";
            linha.children[5].innerHTML = ""; // remove botoes
        }

        if(botao.classList.contains("painel-btn-confirmar")){
            linha.children[4].textContent = "Confirmada";
            linha.children[4].className = "painel-status-confirmada";
            linha.children[5].innerHTML = ""; // remove botoes
        }
            */
    

    document.getElementById("aba-dia").addEventListener("click", () => {
        document.getElementById("painel-dia").style.display = "block";
        document.getElementById("painel-proximos").style.display = "none";
        document.getElementById("aba-dia").classList.add("ativa");
        document.getElementById("aba-proximos").classList.remove("ativa");
    });

    document.getElementById("aba-proximos").addEventListener("click", () => {
        document.getElementById("painel-dia").style.display = "none";
        document.getElementById("painel-proximos").style.display = "block";
        document.getElementById("aba-dias").classList.remove("ativa");
        document.getElementById("aba-proximos").classList.add("ativa");
    })

    document.querySelector(".sair").addEventListener("click", () => {
        window.location.href = "index.html";
    });
});


document.getElementById("link-painel-perfil").addEventListener("click", (e) => {
  e.preventDefault();
  window.location.href = "perfil.html";
}); 

document.getElementById("link-painel-sair").addEventListener("click", (e) => {
  e.preventDefault();
  window.location.href = "index.html";
}); 




/*


const reservasHoje = [
  {
    nome: "Ana Souza",
    data: "08/04/2025",
    horario: "12:00",
    pessoas: 2,
    status: "Confirmada"
  },
  {
    nome: "Carlos Lima",
    data: "08/04/2025",
    horario: "13:30",
    pessoas: 4,
    status: "Confirmada"
  },
  {
    nome: "Juliana Torres",
    data: "08/04/2025",
    horario: "19:00",
    pessoas: 3,
    status: "Confirmada"
  }
];

const reservasFuturas = [
  {
    nome: "Fernanda Alves",
    data: "09/04/2025",
    horario: "18:00",
    pessoas: 2,
    status: "Pendente"
  },
  {
    nome: "Bruno Rocha",
    data: "10/04/2025",
    horario: "20:00",
    pessoas: 5,
    status: "Pendente"
  },
  {
    nome: "Paula Menezes",
    data: "11/04/2025",
    horario: "12:30",
    pessoas: 2,
    status: "Pendente"
  }
];

function carregarReservasHoje() {
  const tbody = document.getElementById("painel-hoje");
  tbody.innerHTML = "";

  reservasHoje.forEach((reserva, index) => {
    const tr = document.createElement("tr");

    tr.innerHTML = `
      <td>${reserva.nome}</td>
      <td>${reserva.data}</td>
      <td>${reserva.horario}</td>
      <td>${reserva.pessoas}</td>
      <td>
        ${reserva.status}
        <button class="painel-btn-cancelar" onclick="cancelarReservaHoje(${index})">Cancelar Reserva</button>
      </td>
    `;

    tbody.appendChild(tr);
  });

  document.getElementById("contador-hoje").textContent = reservasHoje.length;
}

function carregarReservasFuturas() {
  const tbody = document.getElementById("painel-futuras");
  tbody.innerHTML = "";

  reservasFuturas.forEach((reserva, index) => {
    const tr = document.createElement("tr");

    let statusHTML = `
      <button class="painel-btn-confirmar" onclick="confirmarReserva(${index})">Confirmar Reserva</button>
      <button class="painel-btn-cancelar" onclick="cancelarReservaFutura(${index})">Cancelar Reserva</button>
    `;

    if (reserva.status === "Confirmada") {
      statusHTML = `<span style="color: #90ee90; font-weight: bold;">Confirmada</span>`;
    }

    tr.innerHTML = `
      <td>${reserva.nome}</td>
      <td>${reserva.data}</td>
      <td>${reserva.horario}</td>
      <td>${reserva.pessoas}</td>
      <td>${statusHTML}</td>
    `;

    tbody.appendChild(tr);
  });
}

function cancelarReservaHoje(index) {
  reservasHoje.splice(index, 1);
  carregarReservasHoje();
}

function cancelarReservaFutura(index) {
  reservasFuturas.splice(index, 1);
  carregarReservasFuturas();
}

function confirmarReserva(index) {
  reservasFuturas[index].status = "Confirmada";
  carregarReservasFuturas();
}

window.onload = () => {
  carregarReservasHoje();
  carregarReservasFuturas();
};
*/