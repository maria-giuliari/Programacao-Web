document.getElementById("link-fazer-reserva-painel").addEventListener("click", (e) => {
    e.preventDefault();
    window.location.href = "painel.html";
}); 

document.getElementById("link-fazer-reserva-clientes").addEventListener("click", (e) => {
  e.preventDefault();
  window.location.href = "clientes.html";
}); 

document.getElementById("link-fazer-reserva-perfil").addEventListener("click", (e) => {
    e.preventDefault();
    window.location.href = "perfil.html";
  }); 
  
document.getElementById("link-fazer-reserva-sair").addEventListener("click", (e) => {
    e.preventDefault();
    window.location.href = "index.html";
}); 



/* Dropdown Reservas */

const botaoReservas = document.getElementById("btn-fazer-reserva-reservas");
const menuReservas = document.getElementById("menu-reservas-fazer-reserva");

botaoReservas.addEventListener("click", function(e){
    e.preventDefault();
    e.stopPropagation(); // evita q o proximo listener feche o menu imediatamente 
    menuReservas.style.display = menuReservas.style.display === "block" ? "none" : "block";
}); 

// clicar fora fecha o menu
document.addEventListener("click", function(e){
    const isClickInside = botaoReservas.contains(e.target) || menuReservas.contains(e.target);
    if(!isClickInside) {
        menuReservas.style.display = "none";
    }
});


const formReserva = document.querySelector(".form-fazer-reserva");

formReserva.addEventListener("submit", function(e){
    e.preventDefault();

    window.location.href = "visualizar-reservas.html";
});