
document.addEventListener("DOMContentLoaded", function () {
    const reservasHoje = [
        { nome: 'João Silva', data: '07/04/2025', hora: '12:00', pessoas: 3 },
        { nome: 'Maria Costa', data: '07/04/2025', hora: '13:00', pessoas: 2 },
        { nome: 'Carlos Souza', data: '07/04/2025', hora: '14:00', pessoas: 4 },
    ];

    const reservasFuturas = [
        { nome: 'Ana Paula', data: '08/04/2025', hora: '12:00', pessoas: 2 },
        { nome: 'Roberto Lima', data: '09/04/2025', hora: '15:00', pessoas: 6 },
    ];

    const hojeTbody = document.getElementById('painel-hoje');
    const futurasTbody = document.getElementById('painel-futuras');
    const contadorHoje = document.getElementById("contador-hoje");

    reservasHoje.forEach(reserva => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${reserva.nome}</td>
            <td>${reserva.data}</td>
            <td>${reserva.hora}</td>
            <td>${reserva.pessoas}</td>
            <td
                class="painel-status-confirmada">Confirmada
            </td>
            <td>
                <button class="painel-btn-cancelar">Cancelar</button>
            </td>
        `;
        hojeTbody?.appendChild(tr);
    });

    reservasFuturas.forEach(reserva => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${reserva.nome}</td>
            <td>${reserva.data}</td>
            <td>${reserva.hora}</td>
            <td>${reserva.pessoas}</td>
            <td>
                <button class="painel-btn-confirmar">Confirmar</button>
                <button class="painel-btn-cancelar">Cancelar</button>
            </td>
        `;
        futurasTbody?.appendChild(tr);
    });

    contadorHoje.textContent = reservasHoje.length;

    /*
    document.addEventListener("click", (e) => {
        const botao = e.target; 
        if(!botao.matches("button")) return;

        const linha = botao.closest("tr");
        const tabela = linha.closest("tbody");
        
        // cancelar 
       if (botao.classList.contains("painel-btn-cancelar")){
        const celulaStatus = linha.children[5];
        const celulaAcoes = linha.children[5];

        celulaStatus.textContent = "Cancelada";
        celulaStatus.className = "painel-status-cancelada";
        celulaAcoes.innerHTML = ""; //remove botoes
       }

       // confirmar (só existe nas reservas futuras)
       if(botao.classList.contains("painel-btn-confirmar")){
        const celulaStatus = linha.children[5];
        const celulaAcoes = linha.children[5];

        celulaStatus.textContent = "Confirmada";
        celulaStatus.className = "painel-status-confirmada";
        celulaAcoes.innerHTML = ""; // remove botoes
       }
    });
    */

    document.addEventListener("click", (e) => {
      const botao = e.target; 
      if (!botao.matches("button")) return; 

      const linha = botao.closest("tr"); 

      // Cancelar 
      if (botao.classList.contains("painel-btn-cancelar")){
        if (linha.parentElement.id === "painel-hoje") {
          // para tabela do dia
          const celulaStatus = linha.children[4]; 
          const celulaAcoes = linha.children[5]; 
          celulaStatus.textContent = "Cancelada"; 
          celulaStatus.className = "painel-status-cancelada"; 
          celulaAcoes.innerHTML = ""; 
        } else {
          // para próximos dias (futura)
          const celulaAcoes = linha.children[4];
          celulaAcoes.textContent = "Cancelada"; 
          celulaAcoes.className = "painel-status-cancelada";
        }
      }

      // Confirmar (apenas nos proximos dias)
      if(botao.classList.contains("painel-btn-confirmar")) {
        const celulaAcoes = linha.children[4]; 
        celulaAcoes.textContent = "Confirmada"; 
        celulaAcoes.className = "painel-status-confirmada"; 
      }
    });



       /* if(botao.classList.contains("painel-btn-cancelar")){
            linha.children[4].textContent = "Cancelada";
            linha.children[4].className = "painel-status-cancelada";
            linha.children[5].innerHTML = ""; // remove botoes
        }

        if(botao.classList.contains("painel-btn-confirmar")){
            linha.children[4].textContent = "Confirmada";
            linha.children[4].className = "painel-status-confirmada";
            linha.children[5].innerHTML = ""; // remove botoes
        }
            */
    

    document.getElementById("aba-dia").addEventListener("click", () => {
        document.getElementById("painel-dia").style.display = "block";
        document.getElementById("painel-proximos").style.display = "none";
        document.getElementById("aba-dia").classList.add("ativa");
        document.getElementById("aba-proximos").classList.remove("ativa");
    });

    document.getElementById("aba-proximos").addEventListener("click", () => {
        document.getElementById("painel-dia").style.display = "none";
        document.getElementById("painel-proximos").style.display = "block";
        document.getElementById("aba-dia").classList.remove("ativa");
        document.getElementById("aba-proximos").classList.add("ativa");
    })

    document.querySelector(".sair").addEventListener("click", () => {
        window.location.href = "index.html";
    });
});

document.getElementById("link-painel-clientes").addEventListener("click", (e) => {
  e.preventDefault();
  window.location.href = "clientes.html";
}); 

document.getElementById("link-painel-perfil").addEventListener("click", (e) => {
  e.preventDefault();
  window.location.href = "perfil.html";
}); 

document.getElementById("link-painel-sair").addEventListener("click", (e) => {
  e.preventDefault();
  window.location.href = "index.html";
}); 



/* Dropdown Reservas */

document.addEventListener("DOMContentLoaded", function(){
  const botaoReservas = document.getElementById("btn-painel-reservas");
  const menuReservas = document.getElementById("menu-reservas-painel");

  botaoReservas.addEventListener("click", function (e){
    e.preventDefault();
    menuReservas.style.display = menuReservas.style.display === "block" ? "none" : "block";
  });

  //fechar dropdown se clicar fora
  document.addEventListener("click", function (e){
    const isClickInside = botaoReservas.contains(e.target) || menuReservas.contains(e.target);
    if (!isClickInside){
      menuReservas.style.display = "none";
    }
  });
});

